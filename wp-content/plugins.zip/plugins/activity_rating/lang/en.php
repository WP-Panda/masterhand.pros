<?php
return [
	'error' => 'Error! ',
	'something_went_wrong' => 'Something went wrong',
	'access_closed' => 'Access closed',
    
		'amountPayment' => 'Purchases & money transactions',
		'siteVisit' => 'Site visits',
		'oneFieldProfile' => 'Completed profile info',
		'onePortfolio' => 'Number of portfolio jobs',
		'asReferral' => 'As referral',
		'asReferrer' => 'As referrer',
		'forReward' => 'Rewards',
		'forReview' => 'Reviews',
		'forSkill' => 'Skills',
		'forEndorseSkill' => 'Approved skills',
		'projectSuccess' => 'Successfully closed project (via SafePay Deal)',
		'installmentPlan' => 'Trusted Partner program participation',
		'bidAccepted' => 'For the selected project PRO executor',

];