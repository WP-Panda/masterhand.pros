<?php 
// silence is gold