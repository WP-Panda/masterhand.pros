<?php
// silence is gold