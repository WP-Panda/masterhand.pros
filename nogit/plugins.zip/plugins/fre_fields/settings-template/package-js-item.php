<div class="sort-handle"></div>
	<span>{{=post_title }}</span>  
	<span>{{=field_for }}</span>  
	<span>{{=field_type }}</span>  
	{{= post_content }}	
<div class="actions">
	<a href="#" title="Edit" class="icon act-edit" data-icon="p"></a>
	<a href="#" title="Delete" class="icon act-del" data-icon="D"></a>
</div>					
